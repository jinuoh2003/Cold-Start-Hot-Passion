# 1. Baseline 폴더로 이동
cd /home/ubuntu/Cold-Start-Hot-Passion/base_line/src

# 2. 코드 압축
zip -r baseline_function.zip .

# 3. Baseline 람다 함수 생성
awslocal lambda create-function \
    --function-name stress-test-baseline \
    --runtime python3.9 \
    --handler handler.hello_handler \
    --role arn:aws:iam::000000000000:role/lambda-ex \
    --zip-file fileb://baseline_function.zip
