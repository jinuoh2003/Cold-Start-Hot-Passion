awslocal lambda invoke \
    --function-name stress-test-shm \
    --payload '{"test":"shm_event"}' \
    --cli-binary-format raw-in-base64-out \
    response_shm.json


