awslocal lambda invoke \
    --function-name stress-test-baseline \
    --payload '{"test":"baseline_event"}' \
    --cli-binary-format raw-in-base64-out \
    response_baseline.json


